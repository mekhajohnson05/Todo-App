import React, { Component} from 'react'
import './App.css';
import { FaBeer } from 'react-icons/fa';
import 'bootstrap/dist/css/bootstrap.min.css';

import TaskComponents from './component/TaskComponent';
import ViewComponents from './component/ViewComponents';


class App extends Component {
  state={
    divconter:false,
  }
  render() {
    var handlechange= e =>{
      this.setState({divconter:!this.divconter});

    }

    const x=this.state.divconter;
    return(
      <div className="container"
      style={{marginTop:30}}>
       
        <span onClick={handlechange}>{x?'':<b> Add Task</b>}</span>
        {
          x &&(  <div> <TaskComponents/></div>)
          }
           <div>
          <ViewComponents/>
        </div>
      </div>
   
    );
  }
}

export default App;
